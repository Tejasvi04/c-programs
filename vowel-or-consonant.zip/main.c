//Vowel or Consonant
#include <stdio.h>
void main()
{
    char c;
    int lv, uv;
    printf("Enter an alphabet: ");
    scanf("%c", &c);
    lv= (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
    uv= (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U');
    if (lv || uv)
        printf("%c is a vowel.", c);
    else
        printf("%c is a consonant.", c);
}

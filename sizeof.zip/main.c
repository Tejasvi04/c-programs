//sizeof
#include<stdio.h>
void main()
{
    int intt;
    float floatt;
    double doublet;
    char chart;
    printf("Size of int: %ld bytes\n", sizeof(intt));
    printf("Size of float: %ld bytes\n", sizeof(floatt));
    printf("Size of double: %ld bytes\n", sizeof(doublet));
    printf("Size of char: %ld byte\n", sizeof(chart));
}
